---
name: Security report
about: Submit security vulnerability

---

Please submit your security vulnerabilities to @ccw on forum.mtasa.com. Please do not submit them here.

@ccw can be found here: https://forum.mtasa.com/profile/7264-ccw/
